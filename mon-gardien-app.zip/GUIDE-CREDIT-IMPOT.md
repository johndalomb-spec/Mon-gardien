# Crédit d'impôt services à la personne — Guide complet

## ⚠️ Le point le plus important : le mode de paiement

**Les paiements en espèces n'ouvrent JAMAIS droit au crédit d'impôt.** Seuls les paiements traçables — carte bancaire, prélèvement SEPA (GoCardless), virement, chèque — permettent à tes clients de récupérer 50%. C'est une règle stricte de l'administration fiscale, pas une option.

**Conséquence directe sur ta stratégie commerciale** : quand tu proposes une remise pour paiement cash, précise bien au client que dans ce cas, il ne pourra pas bénéficier du crédit d'impôt. Sinon tu risques un client mécontent qui découvre l'an prochain qu'il ne peut rien déclarer, alors qu'il pensait payer "moins cher au final" grâce au crédit d'impôt.

## Le processus, étape par étape

### 1. Préalable : la déclaration SAP (déjà en cours)
Sans ta déclaration SAP enregistrée sur Nova (voir le dossier qu'on avait préparé), rien de ce qui suit n'est possible. Un client qui paie un simple auto-entrepreneur non déclaré SAP n'a **aucun droit** au crédit d'impôt, quel que soit le mode de paiement.

### 2. Facturer chaque client normalement
Utilise le modèle `Facture-Modele-SAP.docx` — il contient déjà les mentions obligatoires (SIRET, identifiant Nova, mention TVA non applicable). Indique toujours le mode de paiement utilisé.

### 3. Avant le 31 mars de l'année suivante : l'attestation fiscale annuelle
C'est une **obligation légale**, pas une option. Utilise `Attestation-Fiscale-Annuelle-Modele.docx` : un document par client, récapitulant toutes les sommes versées dans l'année par moyen traçable. C'est ce document qui sert de justificatif si le client est contrôlé par les impôts.

### 4. Le client déclare lui-même
Le client reporte le montant total (celui de ton attestation) en **case 7DB** de sa déclaration de revenus (annexe 2042 RICI). Depuis 2026, il doit aussi préciser quel prestataire a reçu la somme — raison de plus pour que ton attestation soit complète et exacte.

### 5. Le crédit d'impôt est calculé automatiquement
L'administration fiscale calcule elle-même le crédit d'impôt (50% du montant déclaré, plafonné à 12 000€/an) et l'applique sur l'avis d'imposition du client. Tu n'as rien d'autre à faire une fois l'attestation transmise.

## Ce que tu dois faire concrètement, dès maintenant

1. **Suivre proprement chaque paiement** — note pour chaque client le montant ET le mode de paiement (CB/prélèvement vs espèces), dans un tableau simple si tu n'as pas encore d'outil de facturation automatisé
2. **Garder une trace du SIRET/Nova** sur chaque facture et attestation
3. **Prévoir un rappel pour toi-même fin février/début mars** chaque année, pour envoyer les attestations avant le 31 mars — c'est une obligation, un client qui ne reçoit pas son attestation à temps peut se plaindre légitimement

## Option à explorer plus tard : l'avance immédiate

Il existe un système appelé "avance immédiate du crédit d'impôt" qui permet au client de payer directement son coût réduit (après crédit d'impôt) sans attendre l'année suivante — au lieu de payer 12,90€ puis attendre le crédit d'impôt l'an prochain, le client ne paierait que 6,45€ tout de suite. C'est un vrai argument commercial, mais ça demande de passer par une plateforme partenaire connectée à l'API Urssaf/Tiers de prestation — une démarche plus lourde à mettre en place, à envisager une fois que tu as tes premiers clients réguliers plutôt que dès le lancement.
