# Activer les paiements (Stripe Payment Links — sans code)

Le site contient maintenant 3 formules avec boutons de paiement, mais les liens sont des placeholders. Voici comment les activer, ~15 minutes, sans écrire de code.

## Étape 1 — Créer un compte Stripe
1. https://dashboard.stripe.com/register
2. Renseigne ton SIRET et ton RIB (pour recevoir les paiements)

## Étape 2 — Créer les Payment Links (4 liens au total)
Dans le Dashboard Stripe → Payment Links → "+ Nouveau" :

1. **Sans engagement** : produit récurrent, 8,50€/mois, sans date de fin
2. **Engagement 1 an** : produit récurrent, 8,50€/mois — utilise l'option "essai gratuit" de Stripe réglée sur 6 mois (le client ne paie qu'à partir du 7ème mois, ce qui revient à "6 mois offerts")
3. **Engagement 2 ans, mensuel** : produit récurrent, 8,90€/mois, avec une durée fixée à 24 paiements (option "Nombre de paiements" dans Stripe)
4. **Engagement 2 ans, comptant** : paiement unique (pas récurrent) de 170,88€

Pour chacun, Stripe te donne un lien du type `https://buy.stripe.com/xxxxx`.

## Étape 3 — Me donner les 4 liens
Colle-les-moi et je les intègre directement dans le fichier `mongardien-vitrine.html` (remplacement des 4 lignes marquées `REMPLACER_LIEN...`). Aucune autre modification nécessaire — le site est déjà prêt à les recevoir.

## Ce qui se passe après un paiement
Stripe t'envoie un email de confirmation à chaque vente, et tu peux suivre tous les paiements (mensuels et comptants) directement dans le Dashboard Stripe, avec export possible pour ta compta.
