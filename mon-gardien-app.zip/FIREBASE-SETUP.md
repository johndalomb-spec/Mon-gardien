# Activer les alertes famille (téléphone à téléphone)

Ce que tu as déjà, sans rien faire de plus : une vraie app installable (icône sur l'écran d'accueil), qui détecte l'inactivité et alerte SUR LE TÉLÉPHONE DU SENIOR lui-même.

Ce qui manque encore : que l'alerte arrive sur LE TÉLÉPHONE DE LA FAMILLE quand le senior est inactif. Ça demande un service qui relie les deux appareils. Voici comment l'activer, gratuitement, en ~20 minutes, sans écrire de code.

## Étape 1 — Créer un projet Firebase (gratuit)
1. Va sur https://console.firebase.google.com
2. Connecte-toi avec un compte Google (ou crée-en un)
3. Clique "Ajouter un projet", nomme-le "mon-gardien"
4. Désactive Google Analytics si proposé (pas nécessaire), puis "Créer le projet"

## Étape 2 — Activer Cloud Messaging (les notifications push)
1. Dans le menu de gauche : Engager → Messaging (ou "Cloud Messaging")
2. Clique sur l'icône ⚙️ (Paramètres du projet) → onglet "Cloud Messaging"
3. Sous "Certificats web push", clique "Générer une paire de clés" — copie la clé qui apparaît

## Étape 3 — Récupérer la config du projet
1. Toujours dans Paramètres du projet → onglet "Général"
2. Tout en bas, clique l'icône `</>` (Ajouter une application web)
3. Donne un surnom ("mon-gardien-web"), pas besoin d'hébergement Firebase
4. Copie tout le bloc `firebaseConfig = { ... }` qui s'affiche

## Étape 4 — Active Firestore (la base de données, gratuite jusqu'à un certain volume)
1. Menu de gauche → Compilation → Firestore Database → "Créer une base de données"
2. Mode production, région "eur3 (Europe)"
3. Une fois créée, onglet "Règles" : autorise la lecture/écriture pour les utilisateurs authentifiés (je peux préciser les règles exactes une fois qu'on branche le code)

## Étape 5 — Envoie-moi
- Le bloc `firebaseConfig` de l'étape 3
- La clé VAPID de l'étape 2

Avec ces deux éléments, je branche le code pour que :
- Chaque appareil (senior + famille) s'enregistre dans Firestore
- Quand le senior dépasse le seuil d'inactivité, une notification part automatiquement vers TOUS les téléphones de la famille enregistrés, même app fermée

## Coût réel
Le plan gratuit "Spark" de Firebase couvre largement une seule famille (voire plusieurs dizaines) : notifications illimitées, et une base de données avec un quota gratuit journalier bien au-dessus de ce dont Mon Gardien a besoin. Tu ne paieras que si tu passes plusieurs centaines de clients actifs — et à ce stade, l'abonnement Blaze (paiement à l'usage) restera de l'ordre de quelques euros par mois.
