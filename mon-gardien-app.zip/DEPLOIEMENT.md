# Installer Mon Gardien sur le téléphone d'un client

L'app doit être hébergée sur une vraie adresse web (https://...) pour être installable — un fichier ouvert depuis les messages ou le stockage du téléphone ne permet pas l'installation complète. Voici comment l'héberger gratuitement en 5 minutes.

## Étape 1 — Créer un compte Cloudflare Pages (gratuit, pas de carte bancaire)
1. Va sur https://pages.cloudflare.com
2. Crée un compte (email + mot de passe)

## Étape 2 — Déposer les fichiers
1. Une fois connecté, "Workers & Pages" → "Créer une application" → onglet "Pages" → "Charger des ressources" (Direct Upload)
2. Nomme le projet, ex. "mon-gardien"
3. Glisse-dépose TOUS les fichiers de ce dossier d'un coup :
   - mon-gardien.html
   - mongardien-vitrine.html
   - manifest.json
   - service-worker.js
   - icon-192.png
   - icon-512.png
   - icon-180.png
4. Clique "Déployer le site"

## Étape 3 — Récupérer le lien
Cloudflare te donne une adresse du type `https://mon-gardien.pages.dev`. C'est ce lien (+ `/mon-gardien.html`) que tu partages avec le client, ou que tu transformes en QR code (n'importe quel générateur de QR code gratuit en ligne accepte une URL).

## Étape 4 — Installer chez le client
1. Le client ouvre le lien dans Chrome (Android) ou Safari (iPhone)
2. Un bandeau ou le menu propose "Ajouter à l'écran d'accueil" / "Installer l'application"
3. L'icône Mon Gardien apparaît alors comme une vraie app, pas un raccourci de navigateur

## Pour les mises à jour futures
Chaque fois que je te livre une nouvelle version des fichiers, tu refais juste un nouveau "déploiement" sur le même projet Cloudflare Pages (glisser-déposer les fichiers mis à jour) — le lien reste identique, les clients n'ont rien à réinstaller.
