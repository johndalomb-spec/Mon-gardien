import './style.css';

const state = {
  view: 'home',
  plan: 'libre',
  pay: 'mensuel',
  toast: '',
  alerts: [
    { type: 'warning', title: 'Inactivité — René', text: 'Aucune activité depuis 9h. Dernier contact 08:14.', time: '09:41' },
    { type: 'medicine', title: 'Médicament non confirmé', text: 'René n’a pas confirmé sa prise du midi.', time: '12:30' },
    { type: 'ok', title: 'Tout va bien', text: 'René a confirmé « Je vais bien » à 08:14.', time: '08:14' }
  ],
  events: [
    ['08:14', 'Je vais bien', 'René a confirmé son état.'],
    ['07:52', 'Téléphone actif', 'Déverrouillage détecté.'],
    ['Hier 20:16', 'Médicament confirmé', 'Prise du soir confirmée.']
  ]
};

const plans = {
  libre: { name: 'LIBRE', price: '9,90€', old: '14,90€', sub: '/ mois', label: 'Sans engagement', features: ['Surveillance 24/7', 'Alertes d’inactivité', 'Rappels médicaments', 'Bouton « Je vais bien »', '1 proche aidant'] },
  'un-an': { name: 'SÉRÉNITÉ', price: '7,90€', old: '11,90€', sub: '/ mois', label: 'Engagement 1 an', features: ['Toutes les fonctions Libre', 'Jusqu’à 3 proches aidants', 'Historique étendu', 'Support prioritaire'] },
  'deux-ans': { name: 'FAMILLE', price: '6,90€', old: '9,90€', sub: '/ mois', label: 'Engagement 2 ans', features: ['Toutes les fonctions Sérénité', 'Jusqu’à 5 proches aidants', 'Historique complet', 'Support prioritaire'] }
};

function setView(view) {
  state.view = view;
  render();
  window.scrollTo({top:0, behavior:'smooth'});
}

function toast(message) {
  state.toast = message;
  render();
  setTimeout(() => { state.toast = ''; render(); }, 2500);
}

function header() {
  return `<header>
    <button class="brand" onclick="window.app.setView('home')"><span>🛡️</span> Mon Gardien</button>
    <nav>
      <button onclick="window.app.setView('dashboard')">Tableau de bord</button>
      <button onclick="window.app.setView('pricing')">Tarifs</button>
    </nav>
    <button class="header-cta" onclick="window.app.setView('pricing')">Essai gratuit</button>
  </header>`;
}

function heroArt() {
  return `<div class="hero-art" aria-hidden="true">
    <div class="sun"></div><div class="hill hill-a"></div><div class="hill hill-b"></div>
    <div class="person p1"></div><div class="person p2"></div><div class="heart">♥</div>
  </div>`;
}

function home() {
  return `${header()}
  <main>
    <section class="hero section">
      <div class="eyebrow">🛡️ Veille & sécurité senior</div>
      <h1>Et si votre téléphone protégeait <em>votre maman</em> ?</h1>
      ${heroArt()}
      <p class="lead">Mon Gardien surveille discrètement l’activité du téléphone de votre proche. Aucune activité détectée ? Vous êtes alerté immédiatement. Simple, sans matériel, sans engagement.</p>
      <button class="primary wide" onclick="window.app.setView('pricing')">6 mois offerts — Commencer</button>
      <button class="secondary wide" onclick="document.getElementById('steps').scrollIntoView({behavior:'smooth'})">Voir comment ça marche</button>
    </section>

    <section class="section problem">
      <div class="eyebrow plain">Le problème</div>
      <h2>Vous vous inquiétez pour vos parents. C’est normal.</h2>
      <p>Les solutions classiques nécessitent souvent du matériel et une routine supplémentaire. Mon Gardien part du téléphone qu’ils utilisent déjà.</p>
      <div class="cards">
        <article class="pain"><span>😰</span><h3>L’angoisse du silence</h3><p>Votre proche ne répond plus. Vous ne savez pas s’il dort, s’il est sorti ou s’il a besoin d’aide.</p></article>
        <article class="pain"><span>💊</span><h3>Les médicaments oubliés</h3><p>Un rappel simple et une alerte familiale si une confirmation n’arrive pas.</p></article>
        <article class="pain"><span>📦</span><h3>Pas de boîtier à porter</h3><p>Le téléphone reste l’outil principal : pas de médaillon supplémentaire à penser à porter.</p></article>
      </div>
    </section>

    <section class="solution section">
      <div class="badge">La solution Mon Gardien</div>
      <h2>Le téléphone qu’ils utilisent déjà, devenu leur meilleur allié</h2>
      <p>Pas d’objet à porter. Une application conçue pour rester simple et discrète.</p>
      <div class="solution-art"><div class="phone"><div class="phone-screen">♥<small>08:14</small></div></div><div class="ring r1"></div><div class="ring r2"></div></div>
      <div class="stats"><div><b>30s</b><span>pour installer</span></div><div><b>24/7</b><span>veille</span></div><div><b>0€</b><span>matériel</span></div><div><b>0</b><span>engagement*</span></div></div>
      <button class="light wide" onclick="window.app.setView('pricing')">Commencer gratuitement</button>
    </section>

    <section id="steps" class="section">
      <div class="eyebrow plain">Comment ça marche</div><h2>3 étapes, 30 secondes</h2>
      <div class="steps">
        <article><b>1</b><span>📲</span><h3>On installe ensemble</h3><p>Vous installez l’application sur le téléphone du proche.</p></article>
        <article><b>2</b><span>🔋</span><h3>Elle tourne en silence</h3><p>Le proche n’a pas de routine complexe à retenir.</p></article>
        <article><b>3</b><span>🔔</span><h3>Vous êtes alerté si besoin</h3><p>Une notification claire apparaît lorsqu’un événement nécessite votre attention.</p></article>
      </div>
    </section>

    <section class="section alerts-section">
      <div class="eyebrow plain">Les alertes</div><h2>Ce que vous recevez sur votre téléphone</h2>
      <div class="notification-phone">
        <small>9:41</small>
        ${state.alerts.map(a=>`<div class="notification ${a.type}"><b>${a.title}</b><span>${a.text}</span></div>`).join('')}
      </div>
    </section>

    <section class="section testimonials">
      <div class="eyebrow plain">Témoignages</div><h2>Ce que disent les familles</h2>
      <div class="quote"><b>“</b><p>Mon père vit seul. Avec une solution de veille simple, toute la famille sait quoi faire en cas d’alerte.</p><span>Sophie M. · Fille</span></div>
      <div class="quote"><b>“</b><p>Le bouton « Je vais bien » est rassurant pour ma mère et pour nous.</p><span>Luc D. · Fils</span></div>
    </section>

    <section class="section cta-bottom"><h2>Commencez simplement.</h2><p>Découvrez le tableau de bord de démonstration.</p><button class="primary" onclick="window.app.setView('dashboard')">Ouvrir le tableau de bord</button></section>
  </main>
  ${footer()}`;
}

function dashboard() {
  return `${header()}
  <main class="dashboard section">
    <div class="dashboard-top"><div><div class="eyebrow plain">Espace aidant</div><h1>Bonjour 👋</h1><p>Voici l’état de votre proche aujourd’hui.</p></div><span class="status-pill">● Surveillance active</span></div>
    <div class="profile-card"><div class="avatar">R</div><div><h2>René</h2><p>Dernière activité : aujourd’hui à 08:14</p></div><button onclick="window.app.toast('Appel simulé vers René')">📞 Appeler</button></div>
    <div class="dashboard-grid">
      <article class="metric"><span>État</span><strong class="ok">Tout va bien</strong><small>Confirmation reçue à 08:14</small></article>
      <article class="metric"><span>Activité</span><strong>Normale</strong><small>7 événements aujourd’hui</small></article>
      <article class="metric"><span>Médicaments</span><strong>2 / 2</strong><small>Confirmations reçues</small></article>
    </div>
    <div class="panel"><div class="panel-head"><h2>Alertes récentes</h2><button onclick="window.app.toast('Toutes les alertes sont marquées comme lues')">Tout lire</button></div>
      ${state.alerts.map(a=>`<div class="alert-row"><span class="alert-dot ${a.type}"></span><div><b>${a.title}</b><p>${a.text}</p></div><time>${a.time}</time></div>`).join('')}
    </div>
    <div class="panel"><div class="panel-head"><h2>Historique</h2><button onclick="window.app.toast('Historique complet disponible avec un compte')">Voir tout</button></div>
      ${state.events.map(e=>`<div class="event-row"><time>${e[0]}</time><div><b>${e[1]}</b><p>${e[2]}</p></div></div>`).join('')}
    </div>
    <div class="panel medication"><div class="panel-head"><h2>💊 Rappels</h2><button onclick="window.app.toast('Ajout de rappel — démonstration')">+ Ajouter</button></div>
      <div class="reminder"><b>Matin</b><span>08:00 · confirmé</span><i>✓</i></div>
      <div class="reminder"><b>Midi</b><span>12:30 · confirmation en attente</span><i class="pending">!</i></div>
      <div class="reminder"><b>Soir</b><span>20:00 · programmé</span><i>•</i></div>
    </div>
  </main>
  ${footer()}`;
}

function pricing() {
  const p = plans[state.plan];
  return `${header()}
  <main class="section pricing-page">
    <div class="eyebrow plain">Tarif</div>
    <div class="launch">🔥 Offre de lancement — -50% pendant 3 mois</div>
    <h1>Choisissez votre formule</h1>
    <div class="tabs">
      ${Object.entries(plans).map(([key,val])=>`<button class="${state.plan===key?'active':''}" onclick="window.app.selectPlan('${key}')">${val.label}</button>`).join('')}
    </div>
    ${state.plan!=='libre'?`<div class="pay-toggle"><button class="${state.pay==='mensuel'?'active':''}" onclick="window.app.selectPay('mensuel')">Prélèvement mensuel</button><button class="${state.pay==='comptant'?'active':''}" onclick="window.app.selectPay('comptant')">Paiement comptant <small>-20%</small></button></div>`:''}
    <article class="pricing-card"><span class="star">★ Recommandé</span><p class="plan">${p.name}</p><div class="price"><strong>${p.price}</strong><del>${p.old}</del></div><p>${p.sub} · ${p.label}</p><div class="free">🎁 6 mois offerts à l’ouverture</div>
      <ul>${p.features.map(f=>`<li>✓ ${f}</li>`).join('')}</ul>
    </article>
    <button class="primary wide checkout" onclick="window.app.checkout()">Commencer</button>
    <p class="legal-note">Paiement sécurisé. Cette version contient un parcours de démonstration : aucun paiement réel n’est déclenché.</p>
  </main>
  ${footer()}`;
}

function footer() {
  return `<footer>Mon Gardien — Veille & sécurité senior.<br><span>Prototype MVP · Paiement réel à connecter à Stripe · Données de démonstration</span></footer>`;
}

function render() {
  const root = document.getElementById('app');
  root.innerHTML = state.view==='dashboard' ? dashboard() : state.view==='pricing' ? pricing() : home();
  if (state.toast) {
    const t=document.createElement('div'); t.className='toast'; t.textContent=state.toast; root.appendChild(t);
  }
}

window.app = {
  setView,
  selectPlan(key){ state.plan=key; render(); },
  selectPay(mode){ state.pay=mode; render(); },
  toast,
  checkout(){ toast('Parcours de paiement de démonstration — Stripe sera connecté ensuite.'); }
};
render();
