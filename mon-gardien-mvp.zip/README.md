# Mon Gardien — MVP

Prototype web mobile basé sur le design fourni.

## Lancer le projet

Prérequis : Node.js 20+.

```bash
npm install
npm run dev
```

Puis ouvrir l’adresse affichée par Vite (généralement `http://localhost:5173`).

Pour une version production :

```bash
npm run build
npm run preview
```

## Ce qui est inclus

- Landing page responsive
- Design Mon Gardien
- Tableau de bord aidant avec données de démonstration
- Alertes et historique simulés
- Rappels médicaments simulés
- Parcours tarifaire avec trois formules
- Parcours de paiement de démonstration
- Architecture frontend Vite sans backend externe

## À connecter pour la production

Le projet est volontairement un MVP frontend. Pour une vraie application de surveillance :

1. Authentification et comptes utilisateurs
2. Backend/API et base de données
3. Notifications push
4. Application mobile Android/iOS pour les fonctions en arrière-plan
5. Consentement explicite du proche et gestion des permissions
6. Stripe Payment Links ou Checkout côté serveur
7. Journalisation, sécurité et politique de conservation des données
8. Vérification juridique/RGPD avant commercialisation

Les textes médicaux et les témoignages de la maquette doivent être validés avant publication. Les données présentes dans le tableau de bord sont fictives.
